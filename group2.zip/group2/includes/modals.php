<!-- The Login modal -->
<div class="modal fade" id="login">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark ">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title font-weight-bold">LOGIN</h4>
                <button type="button" class="close text-white font-weight-bold" data-dismiss="modal">X</button>
            </div>

            <form role="form" autocomplete="off">
                <!-- Modal body -->
                <div class="modal-body">
                    <!-- movieid is used on ajax request -->
                    <input class="movieid" type="hidden" value="">

                    <div class="form-group email">
                        <label for="email"><span class="fa fa-email"></span> Email:</label>
                        <input type="email" class="form-control input-gray" name="email" id="email" placeholder="Enter your email"
                               required>
                    </div>

                    <div class="form-group password">
                        <label for="password"><span class="fa fa-password"></span> Password:</label>
                        <input type="password" class="form-control input-gray" name="password" id="password"
                               placeholder="Enter your password" required>
                    </div>

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <h6 class="pull-left signup font-weight-bold text-info">Don't have an account? Signup here! </h6>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="loginButton">Login</button>
                </div>
            </form>

        </div>
    </div>
</div>

<!-- The signup modal -->
<div class="modal fade" id="signup">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark ">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title font-weight-bold">SIGNUP</h4>
                <button type="button" class="close text-white font-weight-bold" data-dismiss="modal">X</button>
            </div>

            <form role="form" autocomplete="off">
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="form-group fullname">
                        <label for="usrname"><span class="fa fa-user"></span>Full Name:</label>
                        <input type="text" class="form-control input-gray" name="name" id="usrame"
                               placeholder="Enter your full name"
                               required>
                    </div>

                    <div class="form-group upemail">
                        <label for="email"><span class="fa fa-email"></span> Email:</label>
                        <input type="email" class="form-control input-gray" name="email" id="email" placeholder="Enter your email"
                               required>
                    </div>

                    <div class="form-group uppassword">
                        <label for="password"><span class="fa fa-password"></span> Password:</label>
                        <input type="password" class="form-control input-gray" name="password" id="password"
                               placeholder="Enter your password" required>
                    </div>

                    <div class="form-group phone">
                        <label for="phone"><span class="fa fa-phone"></span> Phone Number:</label>
                        <input type="tel" class="form-control input-gray" name="phone" id="phone"
                               placeholder="Enter your phone number" required>
                    </div>

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="signupButton">Signup</button>
                </div>
            </form>

        </div>
    </div>
</div>

<!--book modal-->
<div class="modal fade" id="book">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark ">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title font-weight-bold">Book <span class="moviename"></span></h4>
                <button type="button" class="close text-white font-weight-bold" data-dismiss="modal">X</button>
            </div>


            <form role="form" autocomplete="off">
                <!-- Modal body -->
                <div class="modal-body">
                    <!-- movieid is used on ajax request -->
                    <input class="movieid" type="hidden" value="">

                    <div class="form-group email">
                        <label for="email"><span class="fa fa-email"></span> Email:</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email"
                               required readonly>
                    </div>

                    <div class="form-group seats">
                        <label for="seats"><span class="fa fa-email"></span>Number of Seats:</label>
                        <input type="number" min="1"  value="1" class="form-control" name="seats" id="seats"
                               placeholder="Enter number of seats" required>
                    </div>

                    <div class="row mb-3 amntDiv">
                        <div class="col-md-8">
                            <input type="hidden" class="rem_seats" value="">
                            Amount: <span class="amount amnt font-weight-bold"> 5000 </span> Tsh
                        </div>
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <input class="movieid" type="hidden" name="" value="">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="bookButton">Book</button>
                </div>
            </form>

        </div>
    </div>
</div>