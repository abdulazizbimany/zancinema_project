<?php
require_once('functions.php');
environment("production");

if ($_POST['action'] == "booking") {
    $id = secureInput($_POST['id']);
    $email = secureInput($_POST['email']);
    $seats = secureInput($_POST['seats']);
    $currentDate = date('Y-m-d', strtotime("now"));

//    $response =  $email;

    $checkUserExist = db_SelectAll('user', 'email', $email);
    if ($email == @$checkUserExist[0]['email']) {
        $columns = array('movie_id', 'userid', 'date', 'seats');
        $values = array($id, @$checkUserExist[0]['id'], $currentDate, $seats);
        $insertResponse = db_insert('book', $columns, $values);

        $remained_seats = db_SelectAll('movies', 'id', $id);

//        decrementb seats movies table
        $deduct_seats = $remained_seats[0]['remained_seats'] - $seats;
        $updateResponse = db_update('movies', 'remained_seats', $deduct_seats, $id);

        $response = "success";
    }
} else if ($_POST['action'] == "login") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $returnedSession = login("user", "email", $email, "password", $password, 'user', 'email');

    if ($returnedSession != "") {
        $response = $returnedSession;
    } else {
        $response = "";
    }
} else if ($_POST['action'] == "signup") {
    $email = secureInput($_POST['email']);
    $password = securePassword($_POST['password']);
    $fullname = secureInput($_POST['fullname']);
    $phone = secureInput($_POST['phone']);

    $checkUserExist = db_SelectAll('user', 'email', $email);
    if ($email != @$checkUserExist[0]['email']) {

        $columns = array('fullName', 'phone_no', 'email', 'password');
        $values = array($fullname, $phone, $email, $password);

        $signup = db_insert('user', $columns, $values);

        if ($signup == "success") {
            $response = "success";
        } else {
            $response = "error";
        }
    } else {
        $response = "user_exist";
    }
} else {
    accessDeniedMsg("../index.php");
//    header('Location: ../index.php');
}

echo $response;
