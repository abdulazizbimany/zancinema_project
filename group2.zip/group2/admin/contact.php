<?php
require_once("includes/dashboard_header.php");

$query = db_SelectAll('contact', 'null', 'null');

if (isset($_GET['delete'])) {
//    decode id
    $id = base64_decode(urldecode($_GET['id']));
    $response = db_delete('contact', 'id', $id);

    if ($response == "success") { ?>
        <script>
            swal({title: "Success", text: "The comment has been deleted", icon: "success"});
            setTimeout(
                function () {
                    window.location.href = "contact.php";
                }, 2000); //wait for 2 seconds then load index.php
        </script>

        <?php
    } else if ($response == "error") { ?>
        <script>
            swal({title: "Error", text: "The comment has not been deleted", icon: "error"});
            setTimeout(
                function () {
                    window.location.href = "contact.php";
                }, 2000); //wait for 5 seconds then load index.php
        </script>

        <?php
    }
//    header('Location: contact.php');
}


?>

<div class="main col-md-12" style="height: 100%">
    <div class="container-fluid text-center">
        <h4 class="text-center">CONTACT US</h4>
        <div class="mydiv row p-3 mb-5 bg-white rounded">
            <h5>List of Contacts</h5>
            <hr/>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th class="col-md-2">S/N</th>
                    <th class="col-md-3">Name</th>
                    <th class="col-md-3">Email</th>
                    <th class="col-md-4">Comment</th>
                    <th class="col-md-4">Delete</th>
                </tr>
                </thead>
                <tbody>

                <?php
                if (count($query) == 0) { ?>
                    <tr>
                        <td colspan="5">No comment found</td>
                    </tr>
                    <?php
                } else {
                    $x = 1;
                    foreach ($query as $contact) { ?>

                        <tr>
                            <td><?php echo $x ?></td>
                            <td><?php echo $contact['name']; ?> </td>
                            <td><?php echo $contact['email']; ?> </td>
                            <td><?php echo $contact['comment']; ?> </td>
                            <form method="get">
<!--                                encode id for security purpose-->
                                <input type="hidden" name="id" value="<?php echo urlencode(base64_encode($contact['id'])); ?>">
                                <td><input type="submit" class="btn btn-danger" value="Delete" name="delete"></td>
                            </form>


                        </tr>

                        <?php
                        $x++;
                    }
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>