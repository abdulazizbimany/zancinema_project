<?php
require_once("includes/dashboard_header.php");

$query = db_SelectAll('about', 'null', 'null');
$about = $query[0];
?>

<div class="main col-md-12" style="height: 100%">
    <div class="container-fluid text-center">
        <h4 class="text-center">ABOUT US</h4>
        <div class="mydiv row p-3 mb-5 bg-white rounded">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th class="col-md-5">Image</th>
                    <th class="col-md-5">Description</th>
                    <th class="col-md-2">Edit</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><img src="../uploads/<?php echo $about['img'] ?> " width="300" alt=""></td>
                        <td><?php echo $about['description'] ?> </td>
                        <td>
                            <a href="editpage.php?id=<?= urlencode(base64_encode($about['id'])); ?>&page=<?= urlencode(base64_encode("about")); ?>">
                                <button type="button" class="btn btn-primary editBtn">Edit</button>
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</div>



