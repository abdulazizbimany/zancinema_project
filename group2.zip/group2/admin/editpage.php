<?php
require_once("includes/dashboard_header.php");
environment('production');
//decode the submitted id and page name
$id = base64_decode(urldecode($_GET['id']));
$page = base64_decode(urldecode($_GET['page']));

if ($page == "slider") {
    $select = db_SelectAll('slider', 'id', $id);
    $img = $select[0]['img_path'];

    if (isset($_POST['submit'])) {
        $name = 'image';
        @$response = checkIfImage($name);
        if ($response == "image") {
            updateImg($name, "../uploads/", "slider", "img_path", $id, "dashboard.php");
        } else if ($response == "notImage") {
            echo '<script>swal({title: "ERROR", text: "Image is not uploaded", icon: "error" }); </script>';
        }
    }
    ?>
    <div class="main col-md-12" style="height: 100%">
        <div class="container-fluid text-center">
            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h4>EDIT IMAGE SLIDER</h4>
                <hr>

                <div class="col-md-12">
                    <div class="pic_view mt-2 mb-5 col-md-6 pull-left">
                        <img src="../uploads/<?= $img ?>" style="width: 100%" alt="">
                    </div>

                    <div class="mt-2 mb-5 p-5 col-md-6 pull-left ">
                        <h3>Upload new image </h3>
                        <br>
                    </div>
                </div>

                <div class="col-md-12">
                    <form method="post" enctype="multipart/form-data">
                        <input type="file" name="image" id="fileToUpload" value="test">
                        <input class="btn btn-success" type="submit" value="Upload" name="submit">
                    </form>
                </div>

            </div>
        </div>
    </div>

    <?php
} else if ($page == "onthisweek") {
    $con = getConnection();
    $select = db_SelectAll('movies', 'id', $id);
    $movie = $select[0];

    if (isset($_POST['submit'])) {
        $movie_name = secureInput($_POST['name']);
        $movie_day = secureInput($_POST['date']);
        $movie_time = secureInput($_POST['time']);
        $movie_description = secureInput($_POST['desc']);
        $remained_seats = secureInput($_POST['remained_seats']);

        $columns = array('Movie_tittle', 'movie_date', 'show_time', 'description', 'remained_seats');
        $values = array($movie_name, $movie_day, $movie_time, $movie_description, $remained_seats);
        $result = db_update('movies', $columns, $values, $id);

        // upload image
        $name = 'image';
        @$response = checkIfImage($name);
        if ($response == "image") {
            updateImg($name, "../uploads/", "movies", "Moviecover", $id, "dashboard.php");
        } else if ($response == "notImage") {
            header('Location: dashboard.php');
        }
    }
    ?>
    <div class="main col-md-12" style="height: 100%">
        <div class="container-fluid text-center">
            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h4>EDIT ON THIS WEEK MOVIE</h4>
                <form role="form" enctype="multipart/form-data" method="post">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="name"> Name:</label>
                                <input type="text" class="form-control" name="name" placeholder="Enter movie name"
                                       value="<?= $movie['Movie_tittle'] ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="date">Date:</label>
                                <input type="date" class="form-control" name="date" placeholder="Enter movie date"
                                       value="<?= $movie['movie_date'] ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="time"> Time:</label>
                                <input type="time" class="form-control" name="time" placeholder="Enter movie time"
                                       value="<?= $movie['show_time'] ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="desc"> Current Image:</label><br>
                                <img src="../uploads/<?= $movie['Moviecover'] ?>" style="width: 60%" alt="">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="desc"> Description:</label>
                                <input type="text" class="form-control" name="desc"
                                       placeholder="Enter movie description" value="<?= $movie['description'] ?>"
                                       required>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="remained_seats"> Remained Seats:</label><br>
                                <input type="text" class="form-control" name="remained_seats"
                                       placeholder="Enter remained seats" value="<?= $movie['remained_seats'] ?>"
                                       required>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <label for="upload">Upload:</label>
                            <input type="file" name="image" id="fileToUpload">
                        </div>
                    </div>
                    <input type="submit" class="btn btn-success float-right" value="Submit" name="submit">
                </form>
            </div>
        </div>
    </div>

<?php } else if ($page == "commingsoon") {
    $con = getConnection();
    $select = db_SelectAll('soon', 'id', $id);
    $comming = $select[0];

    if (isset($_POST['submit'])) {
        $movie_name = secureInput($_POST['title']);
        $movie_date = secureInput($_POST['date']);

        $columns = array('s_title', 'r_date');
        $values = array($movie_name, $movie_date);
        $result = db_update('soon', $columns, $values, $id);


        $name = 'image';
//        check if image is uploaded
        @$response = checkIfImage($name);
        if ($response == "image") {
            updateImg($name, "../uploads/", "soon", "s_image", $id, "dashboard.php");
        } else if ($response == "notImage") {
            header('Location: dashboard.php');
        }
    }

    ?>
    <div class="main col-md-12" style="height: 100%">
        <div class="container-fluid text-center">
            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h4 class="mt-5 mb-5">EDIT COMMING SOON</h4>
                <form role="form" enctype="multipart/form-data" method="post">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="title"> Movie Name:</label>
                                <input type="text" class="form-control" name="title" placeholder="Enter movie time"
                                       value="<?= $comming['s_title'] ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="date">Releasing Date:</label>
                                <input type="date" class="form-control" name="date" placeholder="Enter movie date"
                                       value="<?= $comming['r_date'] ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label for="upload">Upload:</label>
                            <input type="file" name="image" id="fileToUpload">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="image"> Current Image:</label><br>
                                <img src="../uploads/<?= $comming['s_image'] ?>" style="width: 60%" alt="">
                            </div>
                        </div>
                    </div>
                    <input type="submit" class="btn btn-success float-right" value="Submit" name="submit">
                </form>
            </div>
        </div>
    </div>

    <?php
} else if ($page == "about") {
    $query = db_SelectAll('about', 'null', 'null');
    $about = $query[0];

    if (isset($_POST['submit'])) {
        $con = getConnection();
        $id = $about['id'];
        $about_desc = secureInput($_POST['desc']);
        $name = 'image';

//        check if image is uploaded
        @$response = checkIfImage($name);
        if ($response == "image") {
            updateImg($name, "../uploads/", "about", "img", $id, "about.php");
        } else if ($response == "notImage") {
            header('Location: about.php');
        }

        $result = db_update('about', 'description', $about_desc, $id);

    }
    ?>
    <div class="main col-md-12" style="height: 100%">
        <div class="container-fluid text-center">
            <div class="mydiv row p-3 mb-5 bg-white rounded">


                <form role="form" enctype="multipart/form-data" method="post">
                    <h4>EDIT ABOUT PAGE</h4>
                    <hr>
                    <br>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="image"> Current Image:</label><br>
                                <img src="../uploads/<?= $about['img'] ?>" style="width: 100%" alt="">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="date">Description:</label>
                                <textarea class="form-control" name="desc" placeholder="plaese enter description"
                                          cols="30" rows="10" required><?= $about['description'] ?>
                                </textarea>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label for="upload">Upload:</label><br>
                            <input type="file" name="image" id="fileToUpload">
                        </div>
                    </div>

                    <input type="submit" class="btn btn-success float-right" value="Submit" name="submit">
                </form>

            </div>
        </div>
    </div>

    <?php
} else {
    accessDeniedMsg();
    header('Location: index.php');

    //    header('Location: dashboard.php');
}

// echo '<script>alert('.$id.')</script>'

require_once("includes/dash_footer.php");
?>