<?php
include '../includes/functions.php';

// call function to get connection
$con = getConnection();

//check if redirect this page after session expired
if (@$_GET['msg'] == 'inactive') {
    echo '<script>alert("Session Expired. Please Login Again")</script>';
}

if (isset($_POST['btn_login'])) {
    if (!empty($_POST['user_email'] && !empty($_POST['user_pass']))) {
        $email = $_POST['user_email'];
        $password = $_POST['user_pass'];

//        call login function
        $returnedSession = login("staff", "Email", $email, "password", $password, 'admin', 'Email');

        if ($returnedSession == $email) {
//            echo $returnedSession;
            header('Location: dashboard.php');
        } else {
            echo "<script> alert('Invalid Email or Password')</script>";
        }
    } else {
        echo "<script> alert('Email or Password field cannot be empty')</script>";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- font-awesome  -->
    <link rel="../stylesheet" href="assets/font-awesome/css/font-awesome.min.css">

    <!-- Bootstrap core JavaScript -->
    <script src="../assets/js/jquery-3.2.1.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>

    <!-- javascript bootstrap -->
    <!-- <script src="assets/bootstrap/js/jquery-3.2.1.js"></script> -->
    <script src="../assets/js/popper.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <script src="../assets/sweetalert/sweetalert.js"></script>
    <style>
       body {
           background: url('../uploads/bg2.webp')no-repeat center fixed;
           background-size: auto;
           background-size: cover;
           overflow-x: hidden;
           overflow-y: hidden;
       }
    </style>
</head>

<body style="">
<div class="card col-md-6 mt-5" style="margin: auto">
    <div class="card-head">

    </div>
    <div class="card-body">
        <form method="POST" role="form" autocomplete="off">
            <div class="form-group">
                <label for="usrname"><span class="fa fa-user"></span> Email:</label>
                <input type="email" class="form-control" id="usrname" name="user_email"
                       placeholder="Enter your email address" required>
            </div>
            <div class="form-group">
                <label for="psw"><span class="fa fa-eye"></span> Password:</label>
                <input type="password" class="form-control" id="psw" name="user_pass" placeholder="Enter your password"
                       required>
            </div>
            <button type="submit" class="btn btn-success btn-block login" name="btn_login">
                <span class="fa fa-sign-in"></span> Login
            </button>

        </form>
    </div>
</div>

</body>

</html>