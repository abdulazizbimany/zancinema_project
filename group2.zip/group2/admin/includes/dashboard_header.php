<?php
require_once('../includes/functions.php');

// call function to get connection
$con = getConnection();

//kuzuia error za php if environment == production
environment("production");

//checking the session by function if false return to index.php
checkSession('admin', 'index.php');

//destroy session when user is inactive for 10 minutes
$t = time();
if (isset($_SESSION['logged']) && ($t - $_SESSION['logged'] > (60*10))) {
    logout('index.php?msg=inactive');
} else {
    $_SESSION['logged'] = time();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard | ZanCinema</title>
    <!-- Bootstrap core CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- font-awesome  -->
    <link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
    <!-- Custom styles for this page -->
    <link href="css/dash_style.css" rel="stylesheet">
    <!-- Bootstrap core JavaScript -->
    <script src="../assets/js/jquery-3.2.1.js"></script>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/popper.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <script src="../assets/sweetalert/sweetalert.js"></script>

    <style>
        @media only screen and (max-width: 768px) {
            /* For mobile phones: */
            .goto {
                display: none;
            }
        }

        .bg-info {
            background: #34495e !important;
            color: #fff !important;
        }

        .bg-dark {
            background: #28394a !important;
        }

        /*for scroll botton start*/
        html {
            /*slowmotion pull top*/
            scroll-behavior: smooth;
        }

        #myBtn {
            display: none;
            position: fixed;
            bottom: 15px;
            right: 30px;
            z-index: 99;
            border: none;
            outline: none;
            background-color: black;
            color: white;
            cursor: pointer;
            width: 54px;
            padding: 15px;
            border-radius: 50%;
        }

        /*for scroll botton end */
    </style>
</head>

<body>

<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-info" id="sidebar-wrapper">
        <div class="sidebar-heading bg-dark text-light">ZanCinema</div>
        <div class="list-group list-group-flush">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-info"><i class="fa fa-home"></i>
                Home Page</a>
            <a href="about.php" class="list-group-item list-group-item-action bg-info"><i class="fa fa-user-o"></i>
                About Page</a>
            <a href="contact.php" class="list-group-item list-group-item-action bg-info"><i class="fa fa-envelope"></i>
                Contacts</a>
            <a href="bookings.php" class="list-group-item list-group-item-action bg-info"><i
                        class="fa fa-file-movie-o"></i> Bookings</a>
            <a href="report.php" class="list-group-item list-group-item-action bg-info"><i class="fa fa-file"></i>
                Report</a>
            <a href="users.php" class="list-group-item list-group-item-action bg-info"><i class="fa fa-users"></i> Users</a>
            <a href="setting.php" class="list-group-item list-group-item-action bg-info"><i class="fa fa-gear"></i>
                My Profile</a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

        <nav class="navbar navbar-expand-lg navbar-light bg-info border-bottom">
            <!-- toogle button  -->
            <div class="col-sm-4 col-md-2 text-left">
                <button class="btn bg-dark" id="menu-toggle"><i class="fa fa-bars text-white"></i></button>
            </div>
            <div class="col-sm-4 col-md-8 text-left goto">
                <a href="../index.php" target="_blank">
                    <button class="btn bg-dark"><i class="fa fa-external-link text-white "> Goto Front Page</i>
                    </button>
                </a>
            </div>

            <div class="col-sm-2 col-md-2">
                <a href="logout.php">
                    <button class="btn bg-dark"><i class="fa fa-sign-out text-white"> Logout</i>
                    </button>
                </a>
            </div>
        </nav>

            