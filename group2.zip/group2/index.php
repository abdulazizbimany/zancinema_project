<?php
$page = "Home";
$home = "font-weight-bold active";
$about = $contact = "";
//session_start();
//$_SESSION['user'] = 'true';

require_once("includes/header.php");
$sliders = db_SelectAll('slider', 'null', 'null');
$movies = db_SelectAll('movies', 'null', 'null');
$comming = db_SelectAll('soon', 'null', 'null');
?>

<main>
    <!-- slider start -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <?php
            $class = ['first-slide', 'second-slide', 'third-slide'];
            $x = 0;
            foreach ($sliders as $slider) {
                if ($x > 2) {
                    break;
                } else {
                    if ($x == 0) { ?>
                        <div class="carousel-item active">
                            <img class="<?php echo $class[$x]; ?>" src="uploads/<?php echo $slider['img_path'] ?>">
                        </div>
                        <?php
                    } else { ?>
                        <div class="carousel-item">
                            <img class="<?php echo $class[$x]; ?>" src="uploads/<?php echo $slider['img_path'] ?>">
                        </div>
                    <?php }
                }
                $x++;
            } ?>

        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!-- slider end -->


    <!-- on this week section  start-->
    <div class="container">
        <hr class="hr-head">
        <h2 class="font-weight-bold txt-head doctor-glitch">ON THIS WEEK</h2>
        <div class="row mt-5">
            <div class="col-12 col-sm-12 col-md-12">
                <div class="card-deck ">

                    <?php foreach ($movies as $movie) { ?>

                        <div class="card-wrapper col-lg-3 col-md-6 col-xs-12">
                            <div class="card card-this-week col-md-12 border-0">
                                <div class="card-img-wrapper">
                                    <img class="card-img-top" src="uploads/<?php echo $movie['Moviecover'] ?> "
                                         alt="Card image cap">
                                </div>
                                <div class="card-body this-week text-white">
                                    <h5 class="card-title">
                                        <span>
                                            <?php echo $movie['Movie_tittle']; ?>
                                        </span>
                                        <input type="hidden" class="rem_se"
                                               value="<?php echo $movie['remained_seats']; ?>">
                                        <br>
                                        <span class="movie-category">
                                            <?php $datetime = DateTime::createFromFormat('Ymd', '20210202');
                                            echo $datetime->format('l') . " | " . $movie['show_time'] ?>
                                        </span>
                                    </h5>

                                    <div class="card-content">
                                        <p class="card-text"><?php echo $movie['description'] ?> </p>
                                        <span class="movieid" style="display: none"><?php echo $movie['id'] ?> </span>
                                        <?php if (!isset($_SESSION['user'])) { ?>
                                            <button class="btn btn-gold login" role="button">Book Now
                                            </button>
                                        <?php } else { ?>
                                            <button class="btn btn-gold book" role="button">Book Now</button>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>

                </div>
            </div>
        </div>
    </div>
    <!-- on this week section  end-->

    <div class="container">
        <hr class="hr-dashed">
    </div>

    <!-- coming soon section  start-->
    <div class="container mt-5">
        <hr class="hr-head">
        <h2 class="font-weight-bold txt-head doctor-glitch">COMING SOON</h2>
        <div class="row mt-5">
            <div class="col-12 col-sm-12 col-md-12">
                <div class="card-deck ">
                    <?php foreach ($comming as $soon) { ?>
                        <div class="card-wrapper col-lg-3 col-md-6 col-xs-12">
                            <div class="card col-md-12 border-0">
                                <div class="card-img-wrapper">
                                    <img class="card-img-top" src="uploads/<?php echo $soon['s_image'] ?> "
                                         alt="Card image cap">
                                </div>
                                <div class="card-body text-white coming-soon">
                                    <h5 class="card-title"><?php echo $soon['s_title']; ?> <br>
                                        <span class="movie-category">Release: <?php echo $soon['r_date'] ?> </span>
                                    </h5>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <!-- coming soon section  end-->


        <hr>
    </div>
</main>

<?php
require_once("includes/footer.php");
?>

<script>
    $(document).ready(function () {

        // booking process start
        $('.book').on('click', function () {

            var email = $('.hiddenEmail').val();

            // alert("hello");
            $('#book').modal('show');
            var card = $(this).closest('.this-week');

            var title = card.children('h5').children('span').map(function () {
                return $(this).text();
            }).get();

            var remained_seats = card.children('h5').children('input').map(function () {
                return $(this).val();
            }).get();
            remained_seats = parseInt(remained_seats[0]);

            var id = card.children('.card-content').children('span').map(function () {
                return $(this).text();
            }).get();

            $('.moviename').html(title[0]);
            $('.movieid').val(id[0]);
            $('.rem_seats').val(remained_seats);

            var getForm = $('#bookButton').closest('form');
            var getDiv = getForm.children('.modal-body');

            // insert email to modal (email input) from (input hidden) that got email from session['email']
            getDiv.children('.email').children('input').val(email);

            // automatically calculate amount when entered
            getDiv.children('.seats').children('input').keyup(function () {
                // alert(remained_seats);
                var seats = getDiv.children('.seats').children('input').val();

                // check if entered seats greater than remained seats
                if (seats > remained_seats) {
                    alert("Reamined only " + remained_seats + " seats")
                    getDiv.children('.seats').children('input').val(remained_seats);
                    $('.amnt').text(remained_seats * 5000);

                    var seats = remained_seats;
                } else {
                    $('.amnt').text(seats * 5000);
                }

            });

            $('#bookButton').on('click', function () {
                var getForm = $(this).closest('form');
                var getDiv = getForm.children('.modal-body');

                var email = getDiv.children('.email').children('input').val();

                var seats = getDiv.children('.seats').children('input').val();

                var movieid = getDiv.children('.movieid').map(function () {
                    return $(this).val();
                }).get();

                // alert(email);
                // alert(seats);
                // alert(movieid[0]);

                swal({
                    title: "Do you want to book this movie?",
                    text: "Once you book there is no refund!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                    .then((bookingTrue) => {
                        if (bookingTrue) {
                            // start ajax to submit data in ajaxprocess.php
                            $.ajax({
                                url: "includes/ajaxprocess.php", //url acts the same as action="" in form
                                method: "post",
                                data: {
                                    action: "booking",
                                    id: movieid[0],
                                    email: email,
                                    seats: seats
                                },
                                success: function (data) {
                                    // alert(data);
                                    if (data == "success") {
                                        swal({
                                            title: "Booked!",
                                            icon: "success",
                                        });

                                    } else if (data == "error") {
                                        swal({
                                            title: "Error",
                                            text: "Your booking is failed. Please try again",
                                            icon: "error",
                                        });
                                    }
                                    $('#book').modal('hide');

                                    var email = getDiv.children('.email').children('input').val();
                                    var seats = getDiv.children('.seats').children('input').val();
                                }
                            });

                        } else {
                            swal({
                                text: "The booking process is cancelled",
                                icon: "error",
                            });
                        }
                    });
            });

        });
        // booking process end

    });
</script>