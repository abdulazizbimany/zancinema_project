<?php
$page = "Contact";
$contact = "font-weight-bold active";
$home = $about = "";
require_once("includes/header.php");

if (isset($_POST['submit'])) {
    $name = secureInput($_POST['name']);
    $email = secureInput($_POST['email']);
    $comment = secureInput($_POST['comment']);

    $columns = array('name', 'email', 'comment');
    $values = array($name, $email, $comment);

   $response = db_insert("contact", $columns, $values);

   if($response == "success"){
       echo '<script>swal({title: "Success", text: "Your Comment has been submitted", icon: "success" }); </script>';
   } else if($response == "error"){
       echo '<script>swal({title: "Error", text: "Your Comment has not been submitted", icon: "error" }); </script>';
   }

}
?>

    <main role="main">

        <!--pic in top-->
        <div class="about-section episode-1" style="background-image: url('');">
            <h1>Contact Us</h1>
            <!--            <p>Some text about who we are and what we do.</p>-->
        </div>
        <!--pic in top end-->

        <!-- form  start-->
        <div class="container mt-5">
            <div class="row mt-5 ">
                <div class="form col-md-6 mb-5">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="name"> Name: </label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name"
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="email"> Email:</label>
                            <input type="email" class="form-control" id="usrname" name="email"
                                   placeholder="Enter your email address" required>
                        </div>

                        <div class="form-group mb-5">
                            <div class="form-group">
                                <label for="comment">Comment:</label> <br>
                                <textarea class="form-control" name="comment" rows="3" placeholder="Write your comment..."></textarea>
                            </div>
                        </div>

                        <button type="submit" name="submit" class="btn btn-success pull-right">
                            <span class="fa fa-sign-in"></span> Submit
                        </button>

                    </form>
                </div>

                <!--                map section-->
                <div class="map col-md-6 mb-5">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15867.22618231613!2d39.1965147!3d-6.1566588!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x9a9cecbc74cc93b3!2sZancinema!5e0!3m2!1ssw!2stz!4v1611656618890!5m2!1ssw!2stz"
                            width="100%" height="100%" frameborder="0" style="border:0;"
                            aria-hidden="false" tabindex="0"></iframe>
                </div>

            </div>
            <!--  form  end-->

        </div>
    </main>
<?php
require_once("includes/footer.php");
?>