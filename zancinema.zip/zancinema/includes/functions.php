<?php
//**************************************************************************************************
//                      CONNECTION
//**************************************************************************************************
function getConnection()
{
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "cinema";
    $con = new mysqli($host, $user, $pass, $db);

    // Error handling
    if (mysqli_connect_error()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    return $con;
}

//**************************************************************************************************
//                     (DATABASE) - SELECT * QUERY
//**************************************************************************************************
function db_SelectAll($table, $column, $value)
{
    $con = getConnection();
    if ($value == "null" && $column == "null") {
        $sql = 'select * from ' . $table;
        $result = mysqli_query($con, $sql);
    } else {
        $sql = 'select * from ' . $table . ' where ' . $column . ' = "' . $value . '"';
        $result = mysqli_query($con, $sql);
    }
    $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
    if ($result) {
        return $result;
    } else {
        return "error";
    }
}

//**************************************************************************************************
//                     (DATABASE) - SELECT USING JOIN STATEMENT QUERY
//**************************************************************************************************
function db_SelectJoin($columns, $table, $joins, $whereColumn, $value)
{
    $con = getConnection();
    if ($whereColumn == "null" && $value == "null") {
        $sql = "SELECT " . $columns . "  FROM " . $table . " " . $joins;
        $result = mysqli_query($con, $sql);
    } else {
        $sql = "SELECT " . $columns . "  FROM " . $table . " " . $joins . " " . $whereColumn . " = " . $value;
        $result = mysqli_query($con, $sql);
    }
    $result = mysqli_fetch_all($result, MYSQLI_ASSOC);
    if ($result) {
        return $result;
    } else {
        return "error";
    }
}

//**************************************************************************************************
//                     (DATABASE) - DELETE QUERY
//**************************************************************************************************
function db_delete($table, $whereColumn, $value)
{
    $con = getConnection();
    // sql to delete a record
    $sql = "DELETE FROM $table WHERE $whereColumn = '$value'";

    if (mysqli_query($con, $sql)) {
        return "success";
    } else {
        return "error";
    }
}

//**************************************************************************************************
//                     (DATABASE) - INSERT QUERY
//**************************************************************************************************

function db_insert($table, $columns, $values)
{
    $con = getConnection();
    if (is_array($columns) && is_array($values)) {
        // separate values from array to string by comma
        $c = implode(', ', $columns);
        // movie_id, userid, date, time, seats

        $v = implode('\', \'', $values);
        // 2',' 1',' 2021-02-18',' 23:00',' 7

        $sql = "insert into " . $table . " (" . $c . ") values ('" . $v . "')";
        //insert into book("movie_id, userid, date, time, seats") values('2',' 1',' 2021-02-18',' 23:00',' 7')
    } else {
        $sql = "insert into " . $table . " (" . $columns . ") values ('" . $values . "')";
    }
    $result = mysqli_query($con, $sql);
    if ($result) {
        return "success";
    } else {
        return "error";
    }
}


//**************************************************************************************************
//                     (DATABASE) - UPDATE QUERY
//**************************************************************************************************

function db_update($table, $columns, $values, $id)
{
    $con = getConnection();

    if (is_array($columns) && is_array($values)) {
        $combineColsAndVals = $columns[0] . " = '" . $values[0] . "'";

//        combine all columns with their values
        for ($x = 1; $x < count($columns); $x++) {
            $combineColsAndVals = $combineColsAndVals . ", " . $columns[$x] . " = '" . $values[$x] . "'";
        }
        //write an update statement
        $sql = "UPDATE $table SET $combineColsAndVals where id = '$id'";

    } else {
        $sql = "UPDATE $table SET $columns ='$values' where id = '$id'";
    }

    $result = mysqli_query($con, $sql);
    if ($result) {
        return "success";
    } else {
        return "error";
    }
}


//**************************************************************************************************
//*************************** NOT ( DATABASE FUNCTIONS )*********************************************
//**************************************************************************************************


//**************************************************************************************************
//                      UPDATE IMAGE
//**************************************************************************************************
function updateImg($name, $path, $table, $column, $id, $redirect)
{
    $con = getConnection();

    $target_dir = $path;
    // make the image path to store the image (image name + path)
    $move_file = $target_dir . basename($_FILES[$name]["name"]);
    // get the image name only to be used on query
    $target_file = basename($_FILES[$name]["name"]);
    $uploadOk = 1;
    // get extension of the file
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES[$name]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Allow certain file formats (jpg, png, gif)
    if (
        $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif"
    ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES[$name]["tmp_name"], $move_file)) {
            // run the query
            $sql = "UPDATE " . $table . " SET " . $column . " = '$target_file' where id = '$id'";
            mysqli_query($con, $sql);
            // redirect to dashboard.php
            echo '<script>  window.location.href = "' . $redirect . '";</script>';
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

//**************************************************************************************************
//                      UPLOAD IMAGE
//**************************************************************************************************
function uploadImg($name, $path, $table, $column, $redirect)
{
    $target_dir = $path;
    // make the image path to store the image (image name + path)
    $move_file = $target_dir . basename($_FILES[$name]["name"]);
    // get the image name only to be used on query
    $target_file = basename($_FILES[$name]["name"]);
    $uploadOk = 1;
    // get extension of the file
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES[$name]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Allow certain file formats (jpg, png, gif)
    if (
        $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif"
    ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES[$name]["tmp_name"], $move_file)) {

            db_insert($table, $column, $target_file);

            echo '<script>  window.location.href = "' . $redirect . '";</script>';
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

function checkIfImage($name)
{
    $check = getimagesize($_FILES[$name]["tmp_name"]);
    if ($check != false) {
        return "image";
    } else {
        return "notImage";
    }
}

//**************************************************************************************************
//                      SECURE INPUT
//**************************************************************************************************
function secureInput($input)
{
    $con = getConnection();
    // Prevent Cross-site scripting (remove js, html, php tags)
    $input = strip_tags($input);
    // remove backslashes //
    $input = stripslashes($input);
    // escape special characters
    $input = mysqli_real_escape_string($con, $input);
    return $input;
}

//**************************************************************************************************
//                      SECURE PASSWORD
//**************************************************************************************************
function securePassword($password)
{
    getConnection();
//  constant values for peppers to be used in encryption
    $startPepper = md5("$#9+h");
    $endPepper = md5("&=3k%");

    // run all operations from secureInput() function
    $password = secureInput($password);
    // encrypt (password) by md5, it returns 32 bit characters (length)
    $password = md5($password);
    //Combine both  (password, startPepper, endPepper) and encrypt by hashing using gost algorithm (more secured),
    // it returns 64 bit characters(length)
    $password = hash('gost', ($startPepper . $password . $endPepper));
//    ae6f3b5d0cef88dc752d1f34da7e79149fac3b3e81f557a7798ff3032a12dc7

    return $password;
}

//**************************************************************************************************
//                      LOGIN
//**************************************************************************************************
function login($table, $colEmail, $email, $colPass, $password, $session, $valSession)
{
    $con = getConnection();
    //  strtolower() convert the input to lowercase and trim() remove whitespaces
    $safeEmail = strtolower(trim(secureInput($email)));
    $safePassword = trim(securePassword($password));
    // run query
    $sql = "select * from $table where $colEmail = '$safeEmail' and $colPass = '$safePassword'";
    $result = mysqli_query($con, $sql) or die("Error in query");
    $row = mysqli_fetch_array($result);

    // check if query returned rows > 0 which means the user is in database
    if (count($row)) {
        session_start();
        //$_SESSION['user'] = $row['Staff_id'];
        if ($valSession != 'null') {
            return $_SESSION[$session] = $row[$valSession];
        } else {
            return $_SESSION[$session] = true;
        }
    } else {
        return "";
    }
}

//**************************************************************************************************
//                      LOGOUT
//**************************************************************************************************
function logout($redirect)
{
    session_start();
    session_destroy();
    header('Location:' . $redirect);
}

//**************************************************************************************************
//                     CHECK SESSION
//**************************************************************************************************
function checkSession($varSession, $redirect)
{
    session_start();
    if ($redirect == 'null') {
        if (!isset($_SESSION[$varSession])) {
            return false;
        } else {
            return true;
        }
    } else {
        if (!isset($_SESSION[$varSession])) {
            header('Location: ' . $redirect);
        }
    }
}

function environment($statement)
{
    if ($statement == "development") {
        // Report all PHP errors
        return error_reporting(E_ALL);
    } else if ($statement == "production") {
        //hide all errors
        return error_reporting(0);
    } else {
        echo 'Invalid Environment';
    }
}

function accessDeniedMsg($returnPage)
{
    echo "<body bgcolor='black'>
            <h1 style='color: red; text-align: center'> 403 - ACCESS DENIED</h1> <br>
            <h3 style='color: red; text-align: center'> SORRY, YOU DON'T HAVE PERMISSION TO ACCESS THIS PAGE </h3> <br>
            <h4 style='color: red; text-align: center'> PLEASE RETURN <a href=$returnPage>HERE</a> </h4> <br>
            </body>
         ";
}