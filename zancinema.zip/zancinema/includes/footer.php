<!-- FOOTER -->
<footer class="container-fluid footer">
    <div class="bottom text-center mt-5">
        <p>&copy; <?php auto_copyright("2016");
            function auto_copyright($year = 'auto')
            { ?>
                <?php if (intval($year) == 'auto') {
                $year = date('Y');
            } ?>
                <?php if (intval($year) == date('Y')) {
                echo intval($year);
            } ?>
                <?php if (intval($year) < date('Y')) {
                echo intval($year) . ' - ' . date('Y');
            } ?>
                <?php if (intval($year) > date('Y')) {
                echo date('Y');
            } ?>
            <?php } ?>
            &nbsp; Zancinema &middot; All rights reserved</p>
    </div>


</footer>


<?php include('modals.php') ?>
<!-- Bootstrap core JavaScript
    ================================================== -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function () {

        // login process start
        $('.login').on('click', function () {
            // alert("hello");
            $('#login').modal('show');

            $('#loginButton').on('click', function () {
                var getForm = $(this).closest('form');
                var getDiv = getForm.children('.modal-body');

                var email = getDiv.children('.email').children('input').val();

                var password = getDiv.children('.password').children('input').val();
                //
                // alert(email[0]);
                // alert(password[0]);

                // start ajax to submit data in ajaxprocess.php
                $.ajax({
                    url: "includes/ajaxprocess.php", //url acts the same as action="" in form
                    method: "post",
                    data: {
                        action: "login",
                        email: email,
                        password: password,
                    },
                    success: function (data) {
                        // alert(data);
                        if (data != "" ) {
                            swal({
                                title: "Logged In!",
                                text: "You are now logged in",
                                icon: "success",
                            });
                        } else if (data == "") {
                            swal({
                                title: "Error",
                                text: "You're not logged in",
                                icon: "error",
                            });
                        }
                        $('#book').modal('hide');

                        var email = getDiv.children('.email').children('input').map(function () {
                            return $(this).val("");
                        });

                        var password = getDiv.children('.password').children('input').map(function () {
                            return $(this).val("");
                        });

                        setTimeout(
                            function () {
                                window.location.href = "index.php?e="+data;
                            }, 2000); //wait for 2 seconds then load index.php
                    }
                });

            });

        });
        // login process end

        function putSession($val){
            return $val;
        }

        // login process start
        $('.signup').on('click', function () {
            // alert("hello");

            // show signup modal
            $('#signup').modal('show');

            // hide login
            $('#login').modal('hide');


            // if click signup button
            $('#signupButton').on('click', function () {
                var getForm = $(this).closest('form');
                var getDiv = getForm.children('.modal-body');

                var fullname = getDiv.children('.fullname').children('input').val();

                var email = getDiv.children('.upemail').children('input').val();

                var password = getDiv.children('.uppassword').children('input').val();

                var phone = getDiv.children('.phone').children('input').val();
                //

                // start ajax to submit data in ajaxprocess.php
                $.ajax({
                    url: "includes/ajaxprocess.php", //url acts the same as action="" in form
                    method: "post",
                    data: {
                        action: "signup",
                        fullname: fullname,
                        email: email,
                        phone: phone,
                        password: password
                    },
                    success: function (data) {
                        // alert(data);
                        if (data == "success") {
                            swal({
                                title: "Signed Up!",
                                text: "You are now a registered user",
                                icon: "success",
                            });
                        } else if (data == "error") {
                            swal({
                                title: "Error",
                                text: "Signup process failed",
                                icon: "error",
                            });
                        } else if (data == "user_exist") {
                            swal({
                                title: "Error",
                                text: "The email is already registered, please choose another!",
                                icon: "error",
                            });
                        }
                        $('#signup').modal('hide');

                        var fullname = getDiv.children('.fullname').children('input').val("");

                        var email = getDiv.children('.email').children('input').val("");

                        var password = getDiv.children('.password').children('input').val("");

                        var phone = getDiv.children('.phone').children('input').val("");

                        setTimeout(
                            function()
                            {
                                window.location.href = "index.php";
                            }, 3000); //wait for 3 seconds then load index.php
                    }
                });

            });

        });
        // login process end


    });
</script>

</body>

</html>