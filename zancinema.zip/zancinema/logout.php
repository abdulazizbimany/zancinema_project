<?php
require_once('includes/functions.php');
logout('index.php');

