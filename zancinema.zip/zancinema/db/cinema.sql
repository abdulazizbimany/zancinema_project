-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 27, 2021 at 08:07 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cinema`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `img` varchar(250) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `img`, `description`) VALUES
(1, 'about.jpeg', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad alias aliquid consequuntur cumque deserunt dolores eaque error est facilis, iure laudantium minima obcaecati, odit quisquam saepe sit soluta tempora voluptate. \r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Ad alias aliquid consequuntur cumque deserunt dolores eaque error est facilis, iure laudantium minima obcaecati, odit quisquam saepe sit soluta tempora voluptate?');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `date` date NOT NULL,
  `seats` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `movie_id`, `userid`, `date`, `seats`) VALUES
(61, 1, 4, '2021-02-22', 1),
(66, 1, 4, '2021-02-22', 20),
(67, 3, 4, '2021-02-22', 20),
(68, 4, 4, '2021-02-23', 5),
(69, 1, 5, '2021-02-23', 10),
(70, 3, 4, '2021-02-24', 0),
(71, 2, 4, '2021-02-25', 7),
(72, 3, 6, '2021-02-26', 10),
(73, 1, 4, '2021-02-27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `comment`) VALUES
(19, 'habil', 'habil@gmail.com', 'nn'),
(23, 'yahya', 'yahya@gmail.com', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `Movie_tittle` varchar(50) NOT NULL,
  `movie_date` date NOT NULL,
  `show_time` varchar(30) NOT NULL,
  `Moviecover` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `remained_seats` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `Movie_tittle`, `movie_date`, `show_time`, `Moviecover`, `description`, `remained_seats`) VALUES
(1, 'Taxi Driversnn', '2021-01-13', '20:00', 'cover3.jpeg', 'Turkish movie', 9),
(2, 'Striker testmm', '2021-01-21', '17:20', 'cover2.jpeg', 'Turkish movie', 0),
(3, 'movie_name3', '2021-01-21', '17:20', 'cover.jpeg', 'hhhhhh', 0),
(4, 'movie_name', '2021-02-09', '06:06', 'cover4.jpeg', 'ode classic', 15);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `img_path` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `img_path`) VALUES
(2, 'slider3.jpg'),
(3, 'slider2.jpg'),
(4, 'slider4.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `soon`
--

CREATE TABLE `soon` (
  `id` int(11) NOT NULL,
  `s_title` varchar(100) NOT NULL,
  `r_date` date NOT NULL,
  `s_image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `soon`
--

INSERT INTO `soon` (`id`, `s_title`, `r_date`, `s_image`) VALUES
(1, 'hello test move', '2021-02-24', 'cover3.jpeg'),
(2, 'GENERAL DAUGHTER', '2021-02-11', 'cover3.jpeg'),
(3, 'HUNTER', '2021-03-20', 'cover4.jpeg'),
(4, 'ADU', '2021-02-26', 'cover.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Staff_id` int(20) NOT NULL,
  `FullName` varchar(20) NOT NULL,
  `Phone_no` int(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Staff_id`, `FullName`, `Phone_no`, `Email`, `password`) VALUES
(1, 'abdul', 777777, 'admin@admin.com', 'ae6f3b5d0cef88dc752d1f34da7e79149fac3b3e81f557a7798ff3032a12dc78');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullName` varchar(20) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullName`, `phone_no`, `email`, `password`) VALUES
(4, 'Abdulaziz Said', '333333', 'admin@admin.com', 'ae6f3b5d0cef88dc752d1f34da7e79149fac3b3e81f557a7798ff3032a12dc78'),
(5, 'ode', '67890', 'ode@gmail.com', 'ae6f3b5d0cef88dc752d1f34da7e79149fac3b3e81f557a7798ff3032a12dc78'),
(6, 'Yahya', '123', 'yahya@gmail.com', 'ae6f3b5d0cef88dc752d1f34da7e79149fac3b3e81f557a7798ff3032a12dc78'),
(7, 'Mohd Said', '07775564345', 'mohd@gmail.com', 'ae6f3b5d0cef88dc752d1f34da7e79149fac3b3e81f557a7798ff3032a12dc78');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD KEY `movie_id` (`movie_id`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `soon`
--
ALTER TABLE `soon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Staff_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `soon`
--
ALTER TABLE `soon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `Staff_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movies` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
