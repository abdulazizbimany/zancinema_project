<?php
$page = "About";
$about = "font-weight-bold active";
$home = $contact = "";
require_once("includes/header.php");

$query = db_SelectAll('about', 'null', 'null');
$about = $query[0];
?>

    <main role="main">

        <!--pic in top-->
        <div class="about-section episode-1">
            <h1>About Us</h1>
            <!--            <p>Some text about who we are and what we do.</p>-->
        </div>
        <!--pic in top end-->

        <!-- about section  start-->
        <div class="container mt-5">
            <div class="row mt-5">
                <div class="col-12 col-sm-12 col-md-12">
                    <div class="card-deck ">

                            <div class="card-wrapper col-lg-6 col-md-6 col-xs-12 trajan-pro">
                                <span><?php echo $about['description']; ?></span> <br><span
                                        style="display: none"> <?php echo $about['id'] ?> </span>
                            </div>

                            <!-- description end-->

                            <div class="card-wrapper col-lg-6 col-md-6 col-xs-12">
                                <div class="card col-md-12 border-0">
                                    <div class="card-img-wrapper">
                                        <img class="card-img-top" src="uploads/<?php echo $about['img'] ?> "
                                             alt="Card image cap">
                                    </div>
                                </div>
                            </div>
                        <!--pic end-->

                    </div>
                </div>
            </div>
            <!-- coming soon section  end-->

        </div>
    </main>
<?php
require_once("includes/footer.php");
?>