<?php
require_once("includes/dashboard_header.php");
$con = getConnection();

$rows = db_SelectAll('staff', 'Email', $_SESSION['admin']);
//get one row only
$row = $rows[0];

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = secureInput($_POST['fname']);
    $email = secureInput($_POST['email']);
    $phone = secureInput($_POST['phone']);
    $newpassword = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];

    if (empty($newpassword) && empty($confirmpassword)) {
        $sql = "update staff set FullName ='$name', Email='$email', Phone_no='$phone' where Staff_id='$id'";
        $run = mysqli_query($con, $sql);
        if ($run) {
            header('Location: setting.php');
        } else {
            echo '<script>swal({title: "ERROR", text: "Your info is not updated", icon: "error" }); </script>';
        }
    } else {
        if ($newpassword == $confirmpassword) {
            $newpassword = securePassword($newpassword);
            $confirmpassword = securePassword($confirmpassword);
            $sql = "update staff set FullName ='$name', Email='$email', Phone_no='$phone', password='$newpassword' where Staff_id='$id'";
            $run = mysqli_query($con, $sql);
            if ($run) {
                header('Location: setting.php');
            } else {
                echo '<script>swal({title: "ERROR", text: "Your info is not updated", icon: "error" }); </script>';
            }
        } else {
            echo '<script>swal({title: "ERROR", text: "Passwords does not match", icon: "error" }); </script>';
        }
    }
}
?>
<div class="main" style="height: 700px">

    <div class="container-fluid">
        <h4 class="text-center">MY PROFILE</h4>
        <div class="mydiv row p-3 mb-5 bg-white rounded">
            <form method="post" class="col-md-12">
                <div class="col-md-12 row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?= $row['Staff_id']; ?>">
                            <label for="name"> Full Name:</label>
                            <input type="text" class="form-control" name="fname" placeholder="Enter a fullname"
                                   value="<?= $row['FullName'] ?>" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="name"> Email:</label>
                            <input type="text" class="form-control" name="email" placeholder="Enter email"
                                   value="<?= $row['Email'] ?>" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="name"> Phone Number:</label>
                            <input type="text" class="form-control" name="phone" placeholder="Enter password"
                                   value="<?= $row['Phone_no'] ?>" required>
                        </div>
                    </div>
                </div>

                <h5 class="font-weight-bold" style="margin-top: 20px; margin-bottom: 20px">Change Password
                    <span class="text-danger form-control-sm">(If you dont want to change, leave empty)</span>
                </h5>

                <div class="col-md-12 row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name"> Password:</label>
                            <input type="password" class="form-control" name="password" placeholder="Enter password"
                                   value="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name"> Confirm Password
                                <span class="text-danger">(Same as the password you entered)</span>:</label>
                            <input type="password" class="form-control" name="confirmpassword"
                                   placeholder="repeat the password" value="">
                        </div>
                    </div>

                </div>
                <div class="row col-md-12">
                    <input type="submit" value="Update" name="update" class="btn btn-success">
                </div>
            </form>
        </div>
    </div>

</div>
<?php
require_once("includes/dash_footer.php");
?>
