<?php
require_once("includes/dashboard_header.php");
$con = getConnection();
$rows = db_SelectJoin("book.id, fullName, seats, Movie_tittle, date", "book", "INNER JOIN movies on book.movie_id = movies.id INNER JOIN user ON book.userid = user.id", "null", "null");

if (isset($_GET['delete'])) {
//    decode id
    $id = base64_decode(urldecode($_GET['id']));
    $response = db_delete('book','id', $id);

    if ($response == "success") { ?>
        <script>
            swal({title: "Success", text: "The book has been deleted", icon: "success"});
            setTimeout(
                function () {
                    window.location.href = "bookings.php";
                }, 2000); //wait for 5 seconds then load index.php
        </script>

        <?php
    } else if ($response == "error") { ?>
        <script>
            swal({title: "Error", text: "The book has not been deleted", icon: "error"});
            setTimeout(
                function () {
                    window.location.href = "bookings.php";
                }, 2000); //wait for 5 seconds then load index.php
        </script>

        <?php
    }
//    header('Location: contact.php');
}


?>
    <div class="main" style="height: 700px">

        <div class="container-fluid">
            <h4 class="text-center">BOOKINGS</h4>
            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h5>List of bookings</h5>
                <hr/>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">S/N</th>
                        <th scope="col">Full Name</th>
                        <th scope="col">Movie Title</th>
                        <th scope="col">Seats</th>
                        <th scope="col">Date</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $x = 1;
                    foreach ($rows as $row) { ?>
                        <tr>
                            <!--                            <td style="display: none">-->
                            <?php //echo $row['id'] ?><!-- </td>-->
                            <td><?php echo $x ?></td>
                            <td><?php echo $row['fullName'] ?></td>
                            <td><?php echo $row['Movie_tittle'] ?></td>
                            <td><?php echo $row['seats'] ?></td>
                            <td><?php echo $row['date'] ?></td>
                            <!--encode id and page name before submitting to editpage-->
                            <form method="get">
                                <!--encode id for security purpose-->
                                <input type="hidden" name="id" value="<?php echo urlencode(base64_encode($row['id'])); ?>">
                                <td><input type="submit" class="btn btn-danger" value="Delete" name="delete"></td>
                            </form>
                            </td>
                        </tr>
                        <?php
                        $x++;
                    }
                    ?>
                    </tbody>
                </table>
            </div>

        </div>

    </div>
<?php
require_once("includes/dash_footer.php");
// include("../modals.php");
?>