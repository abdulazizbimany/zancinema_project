<?php
require_once("includes/dashboard_header.php");
$con = getConnection();
$sql = "SELECT date, sum(seats) as totalseats, (sum(seats)*5000) as income FROM book GROUP by date";
$run = mysqli_query($con, $sql);
$rows = mysqli_fetch_all($run, MYSQLI_ASSOC);

//select total seats and total profit
$sqltotal = "SELECT sum(seats) as totalseats, (sum(seats)*5000) as income FROM book";
$runtotal  = mysqli_query($con, $sqltotal);
$rowstotal  = mysqli_fetch_all($runtotal, MYSQLI_ASSOC);
$rowtotal  = $rowstotal[0];

?>
    <div class="main" style="height: 700px">

        <div class="container-fluid">
            <h4 class="text-center">BOOKING REPORT</h4>
            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h5 class="col-md-6">Total Seats: <?= $rowtotal['totalseats']; ?></h5>
                <h5 class="col-md-6">Total Income: <?= $rowtotal['income']; ?></h5>
                <hr/>
                <table class="table table-striped">
                    <thead>
                        <th scope="col">S/N</th>
                        <th scope="col">Date</th>
                        <th scope="col">Total Seats</th>
                        <th scope="col">Income</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $x = 1;
                    foreach ($rows as $row) { ?>
                        <tr>
                            <!--                            <td style="display: none">-->
                            <?php //echo $row['id'] ?><!-- </td>-->
                            <td><?php echo $x ?></td>
                            <td><?php echo $row['date'] ?></td>
                            <td><?php echo $row['totalseats'] ?></td>
                            <td><?php echo $row['income'] ?></td>
                        </tr>
                        <?php
                        $x++;
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php
require_once("includes/dash_footer.php");
// include("../modals.php");
?>