<?php
require_once("includes/dashboard_header.php");

$sliders = db_SelectAll('slider', 'null', 'null');
$movies = db_SelectAll('movies', 'null', 'null');
$comming = db_SelectAll('soon', 'null', 'null');

?>
    <div class="main">

        <div class="container-fluid">
            <h4 class="text-center">HOME PAGE</h4>
            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h5>Slider Images Section</h5>
                <hr/>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">S/N</th>
                        <th scope="col">Image</th>
                        <th scope="col">Edit</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $x = 1;
                    foreach ($sliders as $slider) { ?>
                        <tr>
                            <td style="display: none"><?php echo $slider['id'] ?> </td>
                            <td><?php echo $x ?></td>
                            <td><img src="../uploads/<?php echo $slider['img_path'] ?> " width="100" alt="" value="slider"></td>
                            <td>
<!--                                encode id and page name before submitting to editpage-->
                                <a href="editpage.php?id=<?= urlencode(base64_encode($slider['id'])); ?>&page=<?= urlencode(base64_encode("slider")); ?>">
                                    <button type="button" class="btn btn-primary editBtn">Edit</button>
                                </a>
                            </td>
                        </tr>
                        <?php
                        $x++;
                    }
                    ?>
                    </tbody>
                </table>
            </div>

            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h5> This Week Section </h5>
                <hr/>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">S/N</th>
                            <th scope="col">Movie Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Time</th>
                            <th scope="col">Description</th>
                            <th scope="col">Remained Seats</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $x = 1;
                        foreach ($movies as $movie) { ?>

                            <tr>
                                <td style="display: none"><?php echo $movie['Movie_Id'] ?> </td>
                                <td><?php echo $x ?></td>
                                <td><img src="../uploads/<?php echo $movie['Moviecover'] ?> " width="100" alt=""></td>
                                <td><?php echo $movie['Movie_tittle']; ?> </td>
                                <td><?php echo $movie['show_time'] ?> </td>
                                <td><?php echo $movie['description'] ?>   </td>
                                <td><?php echo $movie['remained_seats'] ?>   </td>
                                <td>
                                    <a href="editpage.php?id=<?= urlencode(base64_encode($movie['id'])); ?>&page=<?= urlencode(base64_encode("onthisweek")); ?>">
                                        <button type="button" class="btn btn-primary editBtn">Edit</button>
                                    </a>
                                </td>
                            </tr>

                            <?php
                            $x++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="mydiv row p-3 mb-5 bg-white rounded">
                <h5> Comming Soon Section </h5>
                <hr/>
                <div class="table-responsive">
                    <table class="table table-striped mb-3 mt-2 bg-white rounded">
                        <thead>
                        <tr>
                            <th scope="col">S/N</th>
                            <th scope="col">Movie Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Releasing Date</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>

                        <?php $x = 1;
                        foreach ($comming as $soon) { ?>
                            <tr>
                                <td style="display: none"><?php echo $soon['id']; ?> </td>
                                <td><?php echo $x ?></td>
                                <td><img src="../uploads/<?php echo $soon['s_image']; ?> " width="100" alt=""></td>
                                <td><?php echo $soon['s_title']; ?></td>
                                <td><?php echo $soon['r_date']; ?> </td>
                                <td>
                                    <a href="editpage.php?id=<?= urlencode(base64_encode($soon['id'])); ?>&page=<?= urlencode(base64_encode("commingsoon")); ?>">
                                        <button type="button" class="btn btn-primary editBtn">Edit</button>
                                    </a>
                                </td>
                            </tr>
                            <?php
                            $x++;
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php
require_once("includes/dash_footer.php");
// include("../modals.php");
?>